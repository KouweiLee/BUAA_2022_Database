import Vuex from 'vuex'


const STORE =  new Vuex.Store({
    state: {
        user: 'liwk'
    },
    getters: {},
    mutations: {},
    actions: {},
    modules: {}

})

export default STORE
