<template>
    <h1>c3</h1>
</template>

<script>
    export default {
        name: "ComponentThree"
    }
</script>

<style scoped>

</style>