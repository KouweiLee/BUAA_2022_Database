<template>
    <h1>c1</h1>
</template>

<script>
    export default {
        name: "ComponentTwoOne"
    }
</script>

<style scoped>

</style>