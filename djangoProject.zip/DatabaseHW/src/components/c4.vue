<template>
    <h1>c4</h1>
</template>

<script>
    export default {
        name: "ComponentFour"
    }
</script>

<style scoped>

</style>