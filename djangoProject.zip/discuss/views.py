from django.views import View
from utils.sqlHelper import SqlHelper
from django.http import JsonResponse
from utils.funcs import *


class AddTitle(View):
    def post(self, request):
        res = {'code': 400, 'msg': '插入主题帖成功', 'data': []}
        request = getRequest(request)
        title = request.get("title")
        content = request.get("content")
        username = request.get("name")
        print("username", username)
        print("title", title)
        try:
            sqlHelper = SqlHelper()
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            dic = {"title": title, "content": content, "username": username,
                   "time": now}
            sqlHelper.insert("dc_title", dic)
            res['code'] = 200
        except Exception as e:
            print(e)
            res['msg'] = "插入主题帖失败"
        return JsonResponse(res)


class DeleteTitle(View):
    def post(self, request):
        res = {'code': 400, 'msg': '删除主题帖成功', 'data': []}
        request = getRequest(request)
        title_id = request.get("title_id")
        try:
            sqlHelper = SqlHelper()
            params = [title_id]
            sqlHelper.executeProcedure("deletetitle", params)
            res['code'] = 200
        except Exception as e:
            print(e)
            res['msg'] = "删除主题帖失败"
        return JsonResponse(res)


class AddComment(View):
    def post(self, request):
        res = {'code': 400, 'msg': '增加评论成功', 'data': []}
        request = getRequest(request)
        title_id = request.get("title_id")
        content = request.get("content")
        username = request.get("username")
        try:
            sqlHelper = SqlHelper()
            params = [title_id, content, username, getNowTime()]
            sqlHelper.executeProcedure("addcomment", params)
            res['code'] = 200
        except:
            res['msg'] = "增加评论失败"
        return JsonResponse(res)

class DeleteComment(View):
    def post(self, request):
        res = {'code': 400, 'msg': '删除评论成功', 'data': []}
        request = getRequest(request)
        comment_id = request.get("comment_id")
        try:
            sqlHelper = SqlHelper()
            params = [comment_id]
            sqlHelper.executeProcedure("deletecomment", params)
            res['code'] = 200
        except:
            res['msg'] = "删除评论失败"
        return JsonResponse(res)


class QueryOneTitle(View):
    def post(self, request):
        res = {'code': 400, 'msg': '进入主题帖成功', 'data': []}
        request = getRequest(request)
        title_id = request.get("title_id")
        try:
            sqlHelper = SqlHelper()
            sql = "select t.id, t.title, t.content, date_format(t.time,'%Y-%m-%d %H:%i:%s'), u.name, u.user_type " \
                  "from dc_title as t, tb_user as u " + \
                  ("where t.id = %d and t.username = u.username" % title_id)
            ares = sqlHelper.executeSql(sql)[0]
            dic = {"title_id": ares[0],
                   "title": ares[1],
                   "content": ares[2],
                   "time": ares[3],
                   "member_name": ares[4],
                   "member_type": ares[5]}
            res['data'].append(dic)
            sql = "select c.id, c.content, date_format(c.time,'%Y-%m-%d %H:%i:%s'), u.name, u.user_type " \
                  "from dc_comment as c, tb_user as u " + \
                  (
                              "where c.id in (select comment_id from dc_com2title where title_id = %d) and c.username = u.username" % title_id)
            results = sqlHelper.executeSql(sql)
            for ares in results:
                dic = {"comment_id": ares[0],
                       "content": ares[1],
                       "time": ares[2],
                       "member_name": ares[3],
                       "member_type": ares[4]}
                res['data'].append(dic)
            res['code'] = 200
        except Exception as e:
            print(e)
            res['msg'] = "进入单个主题帖失败"
        return JsonResponse(res)


class QueryTitle(View):
    def post(self, request):
        res = {'code': 400, 'msg': '按名查询主题帖成功', 'data': []}
        query_string = eval(request.body)
        if query_string == "":
            return self.getAllTitle()
        try:
            sqlHelper = SqlHelper()
            sql = "select t.id, t.title, t.content, date_format(t.time,'%Y-%m-%d %H:%i:%s'), u.name, u.user_type " \
                  "from dc_title as t, tb_user as u " + (
                              "where t.username = u.username and t.title like \'%s%%\'" % query_string)
            results = sqlHelper.executeSql(sql)
            for ares in results:
                dic = {"id": ares[0],
                       "title": ares[1],
                       "content": ares[2],
                       "time": ares[3],
                       "name": ares[4]
                       }
                res['data'].append(dic)
            res['code'] = 200
        except Exception as e:
            print(e)
            res['msg'] = "按名查询主题帖失败"
        return JsonResponse(res)

    def getAllTitle(self):
        res = {'code': 400, 'msg': '查询所有主题帖成功', 'data': []}
        try:
            sqlHelper = SqlHelper()
            sql = "select t.id, t.title, t.content, date_format(t.time,'%Y-%m-%d %H:%i:%s'), u.name, u.user_type " \
                  "from dc_title as t, tb_user as u " \
                  "where t.username = u.username"
            results = sqlHelper.executeSql(sql)
            for ares in results:
                dic = {"id": ares[0],
                       "isTop": 'false',
                       "isOver": 'true',
                       "submitNumber": 100,
                       "replyNumber": 25,
                       "title": ares[1],
                       "url": "404",
                       "content": ares[2],
                       "tags": ['P7'],
                       "time": ares[3],
                       "name": ares[4]
                       # "member_type":ares[5]
                       }
                print(dic)
                res['data'].append(dic)
            res['code'] = 200
        except Exception as e:
            res['msg'] = "查询所有主题帖失败"
        return JsonResponse(res)
