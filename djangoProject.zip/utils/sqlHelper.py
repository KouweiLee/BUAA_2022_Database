from django.db import connection
class SqlHelper():
    def __init__(self):
        try:
            self.con = connection
            self.cursor = self.con.cursor()
        except:
            print("DataBase connect error,please check the db config.")

    def executeProcedure(self, pname, params):
        """
        执行存储过程\n
        :param pname: 存储过程名
        :param params: 存储过程需要的参数
        :return:
        """
        try:
            print(pname, params)
            self.cursor.callproc(pname, params)
        except Exception as e:
            print(e)
            raise e

    def isExistTable(self, tableName):
        sql = "select * from %s" % tableName
        result = self.executeSql(sql)
        if result is None:
            return False
        else:
            return True

    def update(self, tablename, attrs_dict, cond_dict):
        """
        更新数据\n
        :param tablename: 操作的数据库表名
        :param attrs_dict: 更新字典, 格式为{列名:新值}
        :param cond_dict:  更新条件, 格式为{列名:值}
        :return:
        """
        attrs_list = []
        consql = " "
        for k, v in attrs_dict.items():
            #表的属性名不必加引号, 但是属性值需要加
            attrs_list.append(" " + k + " =" + "\'" + str(v) + "\'")
        attrs_sql = ",".join(attrs_list)
        if cond_dict is not None:
            for k, v in cond_dict.items():
                if isinstance(v, str):
                    v = "\'" + v + "\'"
                consql += k + "=" + str(v) + ' and '
        else :
                print("update error because cond_dict is None！")
                return
        consql = consql[:-4]
        sql = "update %s set %s where %s" % (tablename, attrs_sql, consql)
        print(sql)
        self.executeCommit(sql)

    def delete(self, tablename, cond_dict=None):
        """删除数据
        """
        sql = ' '
        if cond_dict is not None:
            for k,v in cond_dict.items():
                if isinstance(v, str):
                    v = "\'" + v + "\'"
                sql += k + "=" + str(v) + ' and '
        else :
            print("delete error because cond_dict is None!")
            return
        sql = sql[:-4]
        sql = "delete from %s where %s" %(tablename, sql)
        print(sql)
        self.executeCommit(sql)

    def insert(self, table, params_dict:dict):
        """
        实现增功能\n
        :param table: 操作的数据库表名
        :param params_dict: 字典型数据, 格式为{列名:值}
        :return: 空
        """
        key = []
        value = []
        for k, v in params_dict.items():
            key.append(k)
            if isinstance(v, str):
                value.append('\'' + v + '\'')
            else :
                value.append(v)
        sql = 'insert into %s' % table
        sql += '(' + ','.join(key) + ')' + ' values(' + ','.join(value) + ')'
        print('insert:' + sql)
        self.executeCommit(sql)

    def select(self, table, column_names=None, cond_dict=None, all=False):
        """
        实现查询功能\n
        :param table: 操作的数据库表名
        :param column_names: 要查询的列名
        :param cond_dict: 查询条件
        :param all: 是否获取所有元组
        :return: 查询结果集
        """
        if all:
            sql = 'select * from ' + table
            return self.executeSql(sql)
        sql = 'select ' + ','.join(column_names) + ' from ' + table#涉及到表属性名的不加引号
        consql = ""
        if cond_dict is not None:
            consql = " where "
            for k, v in cond_dict.items():
                if isinstance(v, str):
                    v = "\'" + v + "\'"
                consql += k + "=" + str(v) + ' and '
            consql = consql[:-4]
        sql += consql
        print(sql)
        return self.executeSql(sql)

    def executeSql(self, sql):
        """
        执行sql语句, 例如查询等不修改数据库的语句\n
        :param sql: sql语句
        :return: 读操作的结果集
        """
        try:
            self.cursor.execute(sql)
            records = self.cursor.fetchall()
            return records
        except Exception as e:
            error = '执行sql语句失败(%s): %s' % (e.args[0], e.args[1])
            print(error)
            raise e

    def executeCommit(self, sql):
        """
        执行sql语句，针对更新，删除等写操作。
        :param sql: sql语句
        :return: 空
        """
        try:
            self.cursor.execute(sql)
            self.con.commit()
        except Exception as e:
            self.con.rollback()
            error = '执行数据库sql语句失败(%s): %s' % (e.args[0], e.args[1])
            print("error:", error)
            raise error

    # def closeDataBase(self):
    #     """
    #     关闭数据库连接
    #     :return: void
    #     """
    #     if self.con:
    #         self.con.close()
    #     else:
    #         print("DataBase doesn't connect,close connectiong error;please check the db config.")
    #

